Progetto di Calcolo Numerico
A.A 2020/21
Componenti del gruppo: Andrea Loretti, Luigi Manieri, Andrea Schinoppi

Il problema che ci è stato posto è il seguente:
Un'azienda vuole commercializzare un dispositivo di acquisizione immagini, del quale si sa che acquisisce con rumore Gaussiano additivo e sfocatura Gaussiana.
L'obiettivo è quello di ricostruire le immagini originali a partire da quelle generate con sfocatura e rumore additivo.

Per svolgere questo progetto è stato utilizzato Google Colaboratory.

Maggiori dettagli nel file 'Relazione_progetto_di_Calcolo_Numerico.pdf'